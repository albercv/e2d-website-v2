"use strict";(()=>{var e={};e.id=9664,e.ids=[9664],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},92048:e=>{e.exports=require("fs")},55315:e=>{e.exports=require("path")},1549:(e,t,o)=>{o.r(t),o.d(t,{originalPathname:()=>g,patchFetch:()=>h,requestAsyncStorage:()=>p,routeModule:()=>d,serverHooks:()=>m,staticGenerationAsyncStorage:()=>u});var r={};o.r(r),o.d(r,{GET:()=>l});var s=o(49303),i=o(88716),a=o(60670),n=o(87070),c=o(4402);async function l(e){let t=e.headers.get("authorization"),o=process.env.CRON_SECRET;if(!o||t!==`Bearer ${o}`)return n.NextResponse.json({error:"Unauthorized"},{status:401});try{console.log("Starting scheduled MCP documentation regeneration...");let e=await (0,c.main)();return n.NextResponse.json({success:!0,message:"MCP documentation regenerated successfully",endpoints:e.endpoints,files:e.files.length,timestamp:new Date().toISOString()})}catch(e){return console.error("Cron MCP regeneration failed:",e),n.NextResponse.json({success:!1,error:e instanceof Error?e.message:"Unknown error",timestamp:new Date().toISOString()},{status:500})}}let d=new s.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/cron/regenerate-mcp/route",pathname:"/api/cron/regenerate-mcp",filename:"route",bundlePath:"app/api/cron/regenerate-mcp/route"},resolvedPagePath:"/Users/albercv/Documents/personalProjects/e2d-website_v2/app/api/cron/regenerate-mcp/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:p,staticGenerationAsyncStorage:u,serverHooks:m}=d,g="/api/cron/regenerate-mcp/route";function h(){return(0,a.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:u})}},4402:(e,t,o)=>{e=o.nmd(e);let r=o(92048),s=o(55315),i={mcpApiDir:s.join(process.cwd(),"app/api/mcp"),docsDir:s.join(process.cwd(),"docs"),outputFiles:{usage:"mcp-usage.md",examples:"mcp-examples.md",changelog:"mcp-changelog.md"}};async function a(){try{console.log("\uD83D\uDE80 Generando documentaci\xf3n MCP..."),r.existsSync(i.docsDir)||(r.mkdirSync(i.docsDir,{recursive:!0}),console.log("\uD83D\uDCC1 Directorio docs creado")),console.log("\uD83D\uDD0D Escaneando endpoints MCP...");let e=function e(t,o=""){let i=[];try{for(let a of r.readdirSync(t)){let n=s.join(t,a);if(r.statSync(n).isDirectory())i.push(...e(n,s.join(o,a)));else if("route.ts"===a||"route.js"===a){let e=function(e){try{let t=r.readFileSync(e,"utf8"),o=t.match(/\/\*\*\s*([\s\S]*?)\s*\*\//);if(!o)return null;let s=o[1],i={description:"",route:"",tool:"",category:"",public:!1,admin:!1,security:"",rateLimit:"",methods:[]},a=s.split("\n").map(e=>e.replace(/^\s*\*\s?/,"")),n=[];for(let e of a)e.startsWith("@route ")?i.route=e.replace("@route ","").trim():e.startsWith("@tool ")?i.tool=e.replace("@tool ","").trim():e.startsWith("@category ")?i.category=e.replace("@category ","").trim():e.startsWith("@public ")?i.public="true"===e.replace("@public ","").trim():e.startsWith("@admin ")?i.admin="true"===e.replace("@admin ","").trim():e.startsWith("@security ")?i.security=e.replace("@security ","").trim():e.startsWith("@ratelimit ")?i.rateLimit=e.replace("@ratelimit ","").trim():!e.startsWith("@")&&e.trim()&&n.push(e.trim());i.description=n.join(" ").trim();let c=t.match(/export\s+(?:async\s+)?function\s+(\w+)/g)||[],l=t.match(/export\s*\{\s*([^}]+)\s*\}/g)||[];return c.forEach(e=>{let t=e.match(/function\s+(\w+)/)?.[1];t&&["GET","POST","PUT","DELETE","PATCH","OPTIONS"].includes(t)&&i.methods.push(t)}),l.forEach(e=>{(e.match(/\{\s*([^}]+)\s*\}/)?.[1]||"").split(",").map(e=>e.trim().split(" as ")[0]).forEach(e=>{["GET","POST","PUT","DELETE","PATCH","OPTIONS"].includes(e)&&i.methods.push(e)})}),i}catch(t){return console.error(`Error extracting info from ${e}:`,t.message),null}}(n);e&&(e.path=o,e.filePath=n,i.push(e))}}}catch(e){console.error(`Error scanning directory ${t}:`,e.message)}return i}(i.mcpApiDir);console.log(`📋 Encontrados ${e.length} endpoints`),console.log("\uD83D\uDCDD Generando documentaci\xf3n de uso...");let t=`# MCP Usage Documentation

## Evolve2Digital MCP Server

Este documento describe c\xf3mo usar los endpoints MCP (Model Context Protocol) de Evolve2Digital.

### Base URL
\`\`\`
${process.env.NEXT_PUBLIC_BASE_URL||"https://evolve2digital.com"}
\`\`\`

### Manifest
Para obtener el manifest completo del servidor MCP:
\`\`\`
GET /api/mcp/manifest
\`\`\`

## Endpoints Disponibles

${e.map(e=>`
### ${e.tool||e.route}

**Descripci\xf3n:** ${e.description}

**Ruta:** \`${e.route}\`
**M\xe9todos:** ${e.methods.join(", ")}
**Categor\xeda:** ${e.category||"general"}
${e.public?"**Acceso:** P\xfablico":""}
${e.admin?"**Acceso:** Administrativo":""}
${e.security?`**Seguridad:** ${e.security}`:""}
${e.rateLimit?`**Rate Limit:** ${e.rateLimit}`:""}

`).join("")}

## Autenticaci\xf3n

### Endpoints P\xfablicos
Los endpoints marcados como p\xfablicos no requieren autenticaci\xf3n.

### Endpoints Administrativos
Los endpoints administrativos requieren autenticaci\xf3n b\xe1sica:
\`\`\`
Authorization: Basic <base64(username:password)>
\`\`\`

## Rate Limiting

Todos los endpoints tienen l\xedmites de velocidad para prevenir abuso:
- **Endpoints p\xfablicos:** 100 requests/minuto por IP
- **Endpoints de herramientas:** 10 requests/hora por IP
- **Endpoints administrativos:** 50 requests/hora por IP autenticado

## Headers Recomendados

\`\`\`
Content-Type: application/json
User-Agent: YourAI/1.0
Accept: application/json
\`\`\`

## Manejo de Errores

Todos los endpoints devuelven errores en formato JSON:
\`\`\`json
{
  "error": "Error type",
  "message": "Detailed error message",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
\`\`\`

### C\xf3digos de Estado Comunes
- **200:** \xc9xito
- **400:** Solicitud inv\xe1lida
- **401:** No autorizado
- **403:** Prohibido
- **429:** Rate limit excedido
- **500:** Error interno del servidor

---

*Documentaci\xf3n generada autom\xe1ticamente el ${new Date().toISOString()}*
`,o=s.join(i.docsDir,i.outputFiles.usage);r.writeFileSync(o,t,"utf8"),console.log(`✅ Generado: ${o}`),console.log("\uD83D\uDCDD Generando documentaci\xf3n de ejemplos...");let a=function(e){let t=e.filter(e=>e.tool);return`# MCP Examples Documentation

## Ejemplos de Uso de Herramientas MCP

Esta documentaci\xf3n proporciona ejemplos pr\xe1cticos de c\xf3mo usar las herramientas MCP de Evolve2Digital.

${t.map(e=>`
## ${e.tool}

**Descripci\xf3n:** ${e.description}

### Ejemplo de Solicitud

\`\`\`bash
curl -X ${e.methods[0]||"POST"} \\
  "${process.env.NEXT_PUBLIC_BASE_URL||"https://evolve2digital.com"}${e.route}" \\
  -H "Content-Type: application/json" \\
  -H "User-Agent: YourAI/1.0" \\
  ${"GET"===e.methods[0]?"":'-d \'{"example": "data"}\' \\'}
\`\`\`

### Ejemplo de Respuesta

\`\`\`json
{
  "tool": "${e.tool}",
  "success": true,
  "data": {},
  "timestamp": "2024-01-01T00:00:00.000Z",
  "processingTime": 150
}
\`\`\`

`).join("")}

## Ejemplos de Integraci\xf3n

### JavaScript/Node.js

\`\`\`javascript
const mcpClient = {
  baseUrl: '${process.env.NEXT_PUBLIC_BASE_URL||"https://evolve2digital.com"}',
  
  async callTool(toolName, data) {
    const response = await fetch(\`\${this.baseUrl}/api/mcp/tools/\${toolName}\`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'MyAI/1.0'
      },
      body: JSON.stringify(data)
    })
    
    return response.json()
  }
}

// Ejemplo de uso
const result = await mcpClient.callTool('posts/search', {
  query: 'microservicios',
  locale: 'es',
  limit: 5
})
\`\`\`

### Python

\`\`\`python
import requests
import json

class MCPClient:
    def __init__(self, base_url="${process.env.NEXT_PUBLIC_BASE_URL||"https://evolve2digital.com"}"):
        self.base_url = base_url
    
    def call_tool(self, tool_name, data):
        url = f"{self.base_url}/api/mcp/tools/{tool_name}"
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'MyAI/1.0'
        }
        
        response = requests.post(url, headers=headers, json=data)
        return response.json()

# Ejemplo de uso
client = MCPClient()
result = client.call_tool('posts/search', {
    'query': 'microservicios',
    'locale': 'es',
    'limit': 5
})
\`\`\`

---

*Documentaci\xf3n generada autom\xe1ticamente el ${new Date().toISOString()}*
`}(e),n=s.join(i.docsDir,i.outputFiles.examples);r.writeFileSync(n,a,"utf8"),console.log(`✅ Generado: ${n}`),console.log("\uD83D\uDCDD Generando changelog...");let c=`# MCP Changelog

## Historial de Cambios del Servidor MCP

### v1.0.0 - ${new Date().toISOString().split("T")[0]}

#### A\xf1adido
- Servidor MCP inicial con protocolo 1.0
- Herramienta \`agent.query\` para consultas al agente IA
- Herramienta \`posts.search\` para b\xfasqueda de art\xedculos
- Herramienta \`appointments.create\` para crear citas
- Endpoint de manifest MCP
- Endpoint de logs administrativos
- Sistema de rate limiting
- Logging completo de actividad
- Documentaci\xf3n autom\xe1tica

#### Caracter\xedsticas
- Soporte para m\xfaltiples modelos de IA (GPT-4, Claude, Gemini)
- Respuestas multiidioma (espa\xf1ol/ingl\xe9s)
- Rate limiting por IP
- Autenticaci\xf3n b\xe1sica para endpoints admin
- Headers CORS optimizados para IA
- Cache inteligente de respuestas
- M\xe9tricas de rendimiento

#### Seguridad
- Rate limiting por endpoint
- Validaci\xf3n de entrada
- Sanitizaci\xf3n de datos
- Headers de seguridad
- Logging de actividad sospechosa

---

*Changelog generado autom\xe1ticamente el ${new Date().toISOString()}*
`,l=s.join(i.docsDir,i.outputFiles.changelog);return r.writeFileSync(l,c,"utf8"),console.log(`✅ Generado: ${l}`),console.log("\uD83C\uDF89 Documentaci\xf3n MCP generada exitosamente!"),{success:!0,endpoints:e.length,files:[o,n,l]}}catch(e){throw console.error("❌ Error generando documentaci\xf3n MCP:",e),e}}o.c[o.s]===e&&a().catch(e=>{console.error("Fatal error:",e),process.exit(1)}),e.exports={main:a}}};var t=require("../../../../webpack-runtime.js");t.C(e);var o=e=>t(t.s=e),r=t.X(0,[8948,5972],()=>o(1549));module.exports=r})();